import HeroSection from "@/components/sections/HeroSection";
import VisionMissionSection from "@/components/sections/VisionMissionSection";
import CoreProductSection from "@/components/sections/CoreProductSection";
import GallerySection from "@/components/sections/GallerySection";
import ValueSection from "@/components/sections/ValueSection";
import CompetitiveSection from "@/components/sections/CompetitiveSection";
import RoadmapSection from "@/components/sections/RoadmapSection";
import FooterSection from "@/components/sections/FooterSection";

const Index = () => {
  return (
    <div className="snap-scroll">
      <HeroSection />
      <VisionMissionSection />
      <CoreProductSection />
      <GallerySection />
      <ValueSection />
      <CompetitiveSection />
      <RoadmapSection />
      <FooterSection />
    </div>
  );
};

export default Index;
