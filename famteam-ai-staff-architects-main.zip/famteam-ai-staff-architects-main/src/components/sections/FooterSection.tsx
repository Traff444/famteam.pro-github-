const FooterSection = () => {
  return (
    <div className="snap-page">
      <div className="poster-container">
        {/* Brand core */}
        <div className="p-6 md:p-10 b-bottom text-center flex-1 flex flex-col justify-center">
          <span className="pill-badge--accent pill-badge mx-auto mb-3">Brand Core</span>
          <h2 className="display-type mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            FAM<span className="text-brand-accent">TEAM</span>
          </h2>
          <p className="mx-auto mb-4" style={{ fontSize: '0.95rem', lineHeight: 1.5, maxWidth: '50ch' }}>
            Мы проектируем и внедряем цифровых сотрудников для бизнеса, тестируя их в собственных процессах, затем адаптируя под клиентов.
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {['Системный архитектор', 'Практик', 'Экспериментатор'].map((tag) => (
              <span key={tag} className="pill-badge">{tag}</span>
            ))}
          </div>
        </div>

        {/* Footer grid */}
        <div className="grid grid-cols-1 md:grid-cols-[200px_1fr_250px]" style={{ minHeight: '180px' }}>
          <div className="flex items-center justify-center b-right" style={{ fontFamily: 'var(--f-display)', fontSize: '6rem' }}>
            #
          </div>
          <div className="flex flex-col items-center justify-center b-right p-4">
            <span className="text-brand-accent" style={{ fontFamily: 'var(--f-display)', fontSize: 'clamp(4rem, 8vw, 8rem)', lineHeight: 0.8 }}>24</span>
            <span className="text-xs font-bold u-caps mt-1">Месяца до платформы</span>
          </div>
          <div className="p-4 flex flex-col justify-between">
            <div className="space-y-1">
              <a href="#" className="block font-bold u-caps text-xs hover:underline" style={{ textDecoration: 'none', color: 'var(--c-black)' }}>Связаться</a>
              <a href="#" className="block font-bold u-caps text-xs hover:underline" style={{ textDecoration: 'none', color: 'var(--c-black)' }}>О нас</a>
              <a href="#" className="block font-bold u-caps text-xs hover:underline" style={{ textDecoration: 'none', color: 'var(--c-black)' }}>Кейсы</a>
            </div>
            <div className="circle-stamp self-end" style={{ width: 60, height: 60, fontSize: '0.45rem' }}>
              <span>AI<br/>Work<br/>Force</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterSection;
