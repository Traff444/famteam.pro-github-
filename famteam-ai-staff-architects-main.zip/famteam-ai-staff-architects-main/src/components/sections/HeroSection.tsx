const HeroSection = () => {
  return (
    <div className="snap-page">
      <div className="poster-container">
        {/* HEADER — compact single row */}
        <div className="flex items-center justify-between px-4 py-3 b-bottom">
          <div className="flex items-center gap-3">
            <div className="brand-pill" style={{ width: 36, height: 52 }}>
              <span className="text-sm leading-none">AI</span>
              <span className="text-[0.5rem] font-bold mt-0.5">WF</span>
            </div>
            <span className="font-bold u-caps text-sm tracking-wide" style={{ fontFamily: 'var(--f-display)' }}>FAMTEAM</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#product" className="text-xs font-bold u-caps hover:text-brand-accent transition-colors">Продукт</a>
            <a href="#gallery" className="text-xs font-bold u-caps hover:text-brand-accent transition-colors">Кейсы</a>
            <a href="#roadmap" className="text-xs font-bold u-caps hover:text-brand-accent transition-colors">Roadmap</a>
            <a href="#contact" className="text-xs font-bold u-caps hover:text-brand-accent transition-colors">Контакты</a>
          </nav>
        </div>

        {/* TITLE BLOCK */}
        <div className="b-bottom overflow-hidden flex-[2] flex flex-col justify-center">
          <span className="massive-type">ЦИФРОВАЯ</span>
          <span className="massive-type" style={{ textAlign: 'left', textAlignLast: 'auto' }}>РАБОЧАЯ <span className="text-brand-accent">СИЛА</span></span>
        </div>

        {/* Content cells */}
        <div className="grid grid-cols-1 md:grid-cols-2 b-bottom flex-[2]">
          <div className="b-right p-4 md:p-6 flex flex-col justify-center">
            <p className="display-type" style={{ fontSize: 'clamp(0.85rem, 3vw, 2.5rem)', fontFamily: "'Anton', sans-serif", fontWeight: 400, lineHeight: 1.15 }}>
              Цифровые <span className="text-brand-accent">роли</span> с <span style={{ fontFamily: 'var(--f-body, sans-serif)', fontWeight: 400, textTransform: 'none' as const }}>KPI</span>, логикой и <span className="text-brand-accent">интеграциями</span>.
            </p>
            <p className="text-sm md:text-base mt-4 leading-relaxed">
              Освобождаем команду от рутины и делаем процессы управляемыми.
            </p>
          </div>
          <div className="hidden md:flex bg-grid-bw items-center justify-center relative">
            <div className="circle-stamp-outer" />
            <div className="circle-stamp flex-col" style={{ width: 180, height: 180, borderColor: 'var(--c-accent)', color: 'var(--c-accent)', fontSize: '0.85rem', position: 'absolute', lineHeight: 1.4 }}>
              <span style={{ color: 'var(--c-black)' }}>BUILT</span>
              <span style={{ fontSize: '0.75rem' }}>FOR BUSINESS</span>
            </div>
          </div>
        </div>

        {/* CTA ROW */}
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center p-3 md:p-4 gap-3">
          <p className="text-xs md:text-sm u-caps font-bold">
            AI-сотрудники для автоматизации бизнес-процессов
          </p>
          <a
            href="#contact"
            className="pill-badge--accent pill-badge text-sm md:text-base px-6 py-2 text-center hover:!bg-[var(--c-accent)] hover:!text-[var(--c-white)] transition-all animate-fade-in"
            style={{ animationDuration: '1.5s', animationDelay: '0.5s', animationFillMode: 'both' }}
          >
            Спроектировать роль для вашего бизнеса
          </a>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
