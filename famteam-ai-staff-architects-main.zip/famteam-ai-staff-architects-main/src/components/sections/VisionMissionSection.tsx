import { useState } from "react";
import heroImage from "@/assets/hero-image.jpg";

const VisionMissionSection = () => {
  const [activeTab, setActiveTab] = useState<"vision" | "mission">("vision");

  return (
    <div className="snap-page">
      <div className="poster-container">
        <div className="grid grid-cols-1 md:grid-cols-[1.5fr_1fr] flex-1">
          <div className="p-6 md:p-10 b-right flex flex-col justify-center">
            <div className="flex gap-2 mb-4">
              <button
                type="button"
                onClick={() => setActiveTab("vision")}
                aria-pressed={activeTab === "vision"}
                className={`pill-badge cursor-pointer transition-colors ${activeTab === "vision" ? "pill-badge--accent" : ""}`}
              >
                Видение
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("mission")}
                aria-pressed={activeTab === "mission"}
                className={`pill-badge cursor-pointer transition-colors ${activeTab === "mission" ? "pill-badge--accent" : ""}`}
              >
                Миссия
              </button>
            </div>

            <h2 className="display-type mb-12" style={{ fontSize: 'clamp(1.8rem, 4vw, 3rem)', fontFamily: 'Oswald, sans-serif', fontWeight: 500 }}>
              {activeTab === "vision" ? (
                <>Архитектура<br /><span className="text-brand-accent">цифровой силы</span></>
              ) : (
                <>Создание<br /><span className="text-brand-accent">AI-сотрудников</span></>
              )}
            </h2>

            <div className="flex flex-col" style={{ minHeight: '360px', maxWidth: '55ch' }}>
              <div style={{ minHeight: '280px' }}>
                {activeTab === "vision" ? (
                  <>
                    {[
                      'Мы видим будущее, в котором каждая компания имеет собственную цифровую рабочую силу — систему AI-сотрудников, встроенных в её процессы.',
                      'Люди сосредоточены на стратегии и развитии, а повторяющиеся и операционные задачи выполняются управляемой цифровой инфраструктурой.',
                    ].map((text, i) => (
                      <div key={i} className="flex gap-4 mb-3">
                        <div className="flex flex-col items-center shrink-0" style={{ width: '20px' }}>
                          <span
                            className="font-mono"
                            style={{ fontSize: '0.75rem', color: 'rgba(255,102,0,0.5)', lineHeight: 1 }}
                          >
                            {String(i + 1).padStart(2, '0')}
                          </span>
                          <div className="flex-1 mt-1" style={{ width: '1px', background: 'rgba(255,102,0,0.3)' }} />
                        </div>
                        <p style={{ fontSize: '0.95rem', lineHeight: 1.7 }}>{text}</p>
                      </div>
                    ))}
                    <div className="flex items-baseline gap-2 mt-2">
                      <svg width="13" height="15" viewBox="0 0 8 10" fill="none" stroke="#FF6600" strokeWidth="0.8" className="shrink-0" style={{ opacity: 0.7, position: 'relative', top: '2px' }}>
                        <rect x="1" y="0" width="2" height="2"/>
                        <rect x="5" y="0" width="2" height="2"/>
                        <rect x="0" y="2" width="8" height="2"/>
                        <rect x="1" y="4" width="6" height="2"/>
                        <rect x="2" y="6" width="4" height="2"/>
                        <rect x="3" y="8" width="2" height="2"/>
                      </svg>
                      <p className="mb-0 italic" style={{ fontSize: '0.95rem', lineHeight: 1.7 }}>
                        «Бизнес становится прозрачным, предсказуемым и масштабируемым.»
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    {[
                      'Помогаем бизнесу превратить разрозненные инструменты и перегруженные процессы в управляемую цифровую рабочую силу.',
                      'Создаём AI-сотрудников под конкретные роли — с ответственностью, логикой и KPI.',
                      'Сначала тестируем архитектуру в собственной практике, затем внедряем её в компании клиентов.',
                    ].map((text, i) => (
                      <div key={i} className="flex gap-4 mb-3">
                        <div className="flex flex-col items-center shrink-0" style={{ width: '20px' }}>
                          <span
                            className="font-mono"
                            style={{ fontSize: '0.75rem', color: 'rgba(255,102,0,0.5)', lineHeight: 1 }}
                          >
                            {String(i + 1).padStart(2, '0')}
                          </span>
                          <div className="flex-1 mt-1" style={{ width: '1px', background: 'rgba(255,102,0,0.3)' }} />
                        </div>
                        <p style={{ fontSize: '0.95rem', lineHeight: 1.7 }}>{text}</p>
                      </div>
                    ))}
                    <div className="flex items-baseline gap-2 mt-2">
                      <svg width="13" height="15" viewBox="0 0 8 10" fill="none" stroke="#FF6600" strokeWidth="0.8" className="shrink-0" style={{ opacity: 0.7, position: 'relative', top: '2px' }}>
                        <rect x="1" y="0" width="2" height="2"/>
                        <rect x="5" y="0" width="2" height="2"/>
                        <rect x="0" y="2" width="8" height="2"/>
                        <rect x="1" y="4" width="6" height="2"/>
                        <rect x="2" y="6" width="4" height="2"/>
                        <rect x="3" y="8" width="2" height="2"/>
                      </svg>
                      <p className="mb-0 italic" style={{ fontSize: '0.95rem', lineHeight: 1.7 }}>
                        «Мы не автоматизируем ради автоматизации, а строим систему, которая действительно работает.»
                      </p>
                    </div>
                  </>
                )}
              </div>
              <span className="pill-badge--accent pill-badge mt-4">Узнать больше →</span>
            </div>
          </div>
          <div className="relative overflow-hidden img-bw">
            <img src={heroImage} alt="AI network" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default VisionMissionSection;
