const CompetitiveSection = () => {
  return (
    <div className="snap-page">
      <div className="poster-container">
        {/* Title rows */}
        <div className="b-bottom overflow-hidden flex items-center" style={{ minHeight: '60px' }}>
          <span className="massive-type" style={{ fontSize: 'clamp(2rem, 7vw, 7rem)' }}>ПОЧЕМУ</span>
        </div>
        <div className="grid grid-cols-2 b-bottom overflow-hidden" style={{ minHeight: '60px' }}>
          <div className="b-right flex items-center">
            <span className="massive-type text-brand-accent" style={{ fontSize: 'clamp(2rem, 7vw, 7rem)' }}>FAM</span>
          </div>
          <div className="flex items-center">
            <span className="massive-type" style={{ fontSize: 'clamp(2rem, 7vw, 7rem)' }}>TEAM</span>
          </div>
        </div>

        {/* 3 differentiators */}
        <div className="grid grid-cols-1 md:grid-cols-3 flex-1">
          {[
            { n: '01', title: 'ИСПОЛЬЗУЕМ САМИ', desc: 'Внедряем в собственные процессы. Продаём проверенную архитектуру.' },
            { n: '02', title: 'ПРАКТИКА', desc: 'Строим роль, тестируем, улучшаем, доводим до результата.' },
            { n: '03', title: 'РОЛИ, НЕ БОТЫ', desc: 'Цифровая роль с ответственностью и KPI, а не чат-бот.' },
          ].map((d, i) => (
            <div
              key={d.n}
              className={`p-5 md:p-6 flex flex-col justify-between ${i < 2 ? 'b-right' : ''} hover:bg-secondary transition-colors`}
            >
              <div>
                <span className="text-brand-accent font-bold" style={{ fontFamily: 'var(--f-display)', fontSize: '2.5rem', lineHeight: 1 }}>{d.n}</span>
                <h3 className="display-type text-lg mt-2 mb-2">{d.title}</h3>
                <p className="text-xs leading-relaxed" style={{ color: '#666' }}>{d.desc}</p>
              </div>
              <div className="accent-line mt-4" />
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="grid grid-cols-4 b-top">
          {['Прозрачность', 'Контроль', 'Предсказуемость', 'Управляемость'].map((w) => (
            <div key={w} className="b-right last:border-r-0 p-2 text-center">
              <span className="font-bold u-caps" style={{ fontSize: '0.65rem' }}>{w}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CompetitiveSection;
