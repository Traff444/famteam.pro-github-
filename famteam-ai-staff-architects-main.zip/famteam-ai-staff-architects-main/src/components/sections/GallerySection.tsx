import gallery01 from "@/assets/gallery-01.jpg";
import gallery02 from "@/assets/gallery-02.jpg";
import gallery03 from "@/assets/gallery-03.jpg";

const galleryItems = [
  { num: 'NO. 001', year: '2024', label: 'AI МЕНЕДЖЕР', img: gallery01 },
  { num: 'NO. 002', year: '2025', label: 'AI АНАЛИТИК', img: gallery02 },
  { num: 'NO. 003', year: '2025', label: 'AI ПАРТНЁР', img: gallery03 },
];

const GallerySection = () => {
  return (
    <div className="snap-page">
      <div className="poster-container">
        <div className="b-bottom overflow-hidden flex items-center" style={{ minHeight: '80px' }}>
          <span className="massive-type" style={{ fontSize: 'clamp(2.5rem, 8vw, 8rem)' }}>ПРОДУКТЫ</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 flex-1">
          {galleryItems.map((item, i) => (
            <div
              key={item.num}
              className={`gallery-item relative flex flex-col justify-between p-4 overflow-hidden transition-colors hover:bg-secondary ${i < 2 ? 'b-right' : ''}`}
            >
              <div className="gallery-meta relative z-10 flex justify-between font-bold text-xs">
                <span>{item.num}</span>
                <span>{item.year}</span>
              </div>
              <div className="gallery-img-wrapper" style={{ backgroundImage: `url(${item.img})` }} />
              <div className="gallery-meta relative z-10 flex justify-between font-bold text-xs">
                <span className="text-brand-accent">{item.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GallerySection;
