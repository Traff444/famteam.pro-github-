const CoreProductSection = () => {
  const cards = [
    { num: '01', title: 'КОММУНИКАЦИЯ\nС КЛИЕНТАМИ', items: ['Отвечает на сообщения клиентов', 'Ведёт чаты и голосовые звонки', 'Работает в Telegram и мессенджерах'] },
    { num: '02', title: 'ПОДДЕРЖКА\nПРОДАЖ', items: ['Квалифицирует лиды', 'Назначает встречи', 'Ведёт клиента по воронке'] },
    { num: '03', title: 'УПРАВЛЕНИЕ\nЗАДАЧАМИ', items: ['Создаёт и обновляет задачи', 'Отслеживает процессы', 'Координирует действия команды'] },
    { num: '04', title: 'CRM\nИ СИСТЕМЫ', items: ['Записывает данные в CRM', 'Обновляет статусы', 'Подключает API и базы данных'] },
    { num: '05', title: 'АНАЛИТИКА\nИ УЛУЧШЕНИЯ', items: ['Анализирует результаты', 'Находит проблемы в процессах', 'Постоянно улучшает работу'] },
  ];

  return (
    <div className="snap-page">
      <div className="poster-container">
        {/* Header bar */}
        <div className="px-3 py-2 lg:p-4 b-bottom flex items-center gap-2 lg:gap-4" style={{ background: 'var(--c-accent)' }}>
          <h2 style={{ fontSize: 'clamp(1.39rem, 3.3vw, 2.19rem)', color: 'var(--c-white)', fontFamily: "'Oswald', sans-serif", fontWeight: 400, textTransform: 'uppercase', lineHeight: 0.9, transform: 'scaleY(1.3)', transformOrigin: 'center', letterSpacing: '0.04em' }}>
            Что делает AI-сотрудник
          </h2>
        </div>


        {/* Cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 flex-1">
          {cards.map((card) => (
            <div key={card.num} className="layer-card flex flex-col justify-between">
              <div>
                <div className="layer-num mb-2 h-[2.5rem] lg:h-[2.5rem]">{card.num}</div>
                <svg width="40" height="6" viewBox="0 0 40 6" className="mb-3" style={{ overflow: 'visible' }}>
                  <path d="M0 3 Q5 1, 10 3 T20 3 T30 2.5 T40 3.5" stroke="var(--c-accent)" strokeWidth="1.8" fill="none" strokeLinecap="round" />
                </svg>
                <h3 className="display-type text-sm lg:text-base mb-3 h-[3.2rem] lg:h-[2.5rem] whitespace-pre-line" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 400 }}>{card.title}</h3>
                <ul className="space-y-1.5">
                  {card.items.map((item) => (
                    <li key={item} className="text-xs flex items-start gap-1.5">
                      <span className="text-brand-accent font-bold mt-0.5">→</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom note */}
        <div className="px-4 py-2 lg:px-6 lg:py-3 b-top text-center">
          <p className="text-[0.65rem] lg:text-xs u-caps font-semibold" style={{ color: '#999', letterSpacing: '0.1em' }}>
            Каждый AI-сотрудник проектируется под конкретную роль в бизнесе
          </p>
        </div>
      </div>
    </div>
  );
};

export default CoreProductSection;
